import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, date, time, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User role enum
export const userRoleEnum = pgEnum("user_role", ["admin", "teacher", "student"]);

// Users table with role
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: userRoleEnum("role").notNull().default("student"),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Notices table
export const notices = pgTable("notices", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  authorId: integer("author_id").references(() => users.id).notNull(),
  imageUrl: text("image_url"),
  isPublished: boolean("is_published").default(true).notNull(),
});

// File Uploads table
export const fileUploads = pgTable("file_uploads", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  path: text("path").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
  uploaderId: integer("uploader_id").references(() => users.id).notNull(),
});

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  code: text("code").notNull().unique(),
  teacherId: integer("teacher_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

// Student Enrollments table (many-to-many relationship between students and courses)
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => users.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  enrolledAt: timestamp("enrolled_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

// Assignments table
export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  dueDate: timestamp("due_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  totalPoints: integer("total_points").notNull().default(100),
  attachmentId: integer("attachment_id").references(() => fileUploads.id),
});

// Assignment Submissions table
export const submissions = pgTable("submissions", {
  id: serial("id").primaryKey(),
  assignmentId: integer("assignment_id").references(() => assignments.id).notNull(),
  studentId: integer("student_id").references(() => users.id).notNull(),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
  content: text("content"),
  attachmentId: integer("attachment_id").references(() => fileUploads.id),
  grade: integer("grade"),
  feedback: text("feedback"),
  isLate: boolean("is_late").default(false).notNull(),
});

// Attendance table
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => users.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  date: date("date").notNull(),
  status: text("status").notNull().default("present"), // present, absent, late, excused
  remarks: text("remarks"),
});

// Schedule table
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  dayOfWeek: integer("day_of_week").notNull(), // 0 = Sunday, 1 = Monday, etc.
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  room: text("room").notNull(),
});

// Define user relations
export const usersRelations = relations(users, ({ many, one }) => ({
  notices: many(notices),
  uploads: many(fileUploads),
  enrollments: many(enrollments),
  taughtCourses: many(courses, { relationName: "teacher" }),
  submissions: many(submissions),
  attendanceRecords: many(attendance),
}));

// Define notice relations
export const noticesRelations = relations(notices, ({ one }) => ({
  author: one(users, {
    fields: [notices.authorId],
    references: [users.id],
  }),
}));

// Define file upload relations
export const fileUploadsRelations = relations(fileUploads, ({ one }) => ({
  uploader: one(users, {
    fields: [fileUploads.uploaderId],
    references: [users.id],
  }),
}));

// Define course relations
export const coursesRelations = relations(courses, ({ one, many }) => ({
  teacher: one(users, {
    fields: [courses.teacherId],
    references: [users.id],
    relationName: "teacher",
  }),
  enrollments: many(enrollments),
  assignments: many(assignments),
  schedules: many(schedules),
  attendanceRecords: many(attendance),
}));

// Define enrollment relations
export const enrollmentsRelations = relations(enrollments, ({ one }) => ({
  student: one(users, {
    fields: [enrollments.studentId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [enrollments.courseId],
    references: [courses.id],
  }),
}));

// Define assignment relations
export const assignmentsRelations = relations(assignments, ({ one, many }) => ({
  course: one(courses, {
    fields: [assignments.courseId],
    references: [courses.id],
  }),
  attachment: one(fileUploads, {
    fields: [assignments.attachmentId],
    references: [fileUploads.id],
  }),
  submissions: many(submissions),
}));

// Define submission relations
export const submissionsRelations = relations(submissions, ({ one }) => ({
  assignment: one(assignments, {
    fields: [submissions.assignmentId],
    references: [assignments.id],
  }),
  student: one(users, {
    fields: [submissions.studentId],
    references: [users.id],
  }),
  attachment: one(fileUploads, {
    fields: [submissions.attachmentId],
    references: [fileUploads.id],
  }),
}));

// Define attendance relations
export const attendanceRelations = relations(attendance, ({ one }) => ({
  student: one(users, {
    fields: [attendance.studentId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [attendance.courseId],
    references: [courses.id],
  }),
}));

// Define schedule relations
export const schedulesRelations = relations(schedules, ({ one }) => ({
  course: one(courses, {
    fields: [schedules.courseId],
    references: [courses.id],
  }),
}));

// Insert schemas for validation
export const insertUserSchema = createInsertSchema(users, {
  role: z.enum(["admin", "teacher", "student"]),
}).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  email: true,
});

export const insertNoticeSchema = createInsertSchema(notices).pick({
  title: true,
  content: true,
  authorId: true,
  imageUrl: true,
  isPublished: true,
});

export const insertFileUploadSchema = createInsertSchema(fileUploads).pick({
  filename: true,
  originalName: true,
  mimeType: true,
  size: true,
  path: true, 
  uploaderId: true,
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  name: true,
  description: true,
  code: true,
  teacherId: true,
  isActive: true,
});

export const insertEnrollmentSchema = createInsertSchema(enrollments).pick({
  studentId: true,
  courseId: true,
  isActive: true,
});

export const insertAssignmentSchema = createInsertSchema(assignments).pick({
  title: true,
  description: true,
  courseId: true,
  dueDate: true,
  totalPoints: true,
  attachmentId: true,
});

export const insertSubmissionSchema = createInsertSchema(submissions).pick({
  assignmentId: true,
  studentId: true,
  content: true,
  attachmentId: true,
  grade: true,
  feedback: true,
  isLate: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).pick({
  studentId: true,
  courseId: true,
  date: true,
  status: true,
  remarks: true,
});

export const insertScheduleSchema = createInsertSchema(schedules).pick({
  courseId: true,
  dayOfWeek: true,
  startTime: true,
  endTime: true,
  room: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertNotice = z.infer<typeof insertNoticeSchema>;
export type Notice = typeof notices.$inferSelect;

export type InsertFileUpload = z.infer<typeof insertFileUploadSchema>;
export type FileUpload = typeof fileUploads.$inferSelect;

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Enrollment = typeof enrollments.$inferSelect;

export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignments.$inferSelect;

export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissions.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

// User Role type
export type UserRole = "admin" | "teacher" | "student";

// Attendance status type
export type AttendanceStatus = "present" | "absent" | "late" | "excused";
