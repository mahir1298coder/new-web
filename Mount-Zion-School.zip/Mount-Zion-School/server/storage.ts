import { 
  users, 
  notices, 
  fileUploads, 
  courses,
  enrollments,
  assignments,
  submissions,
  attendance,
  schedules,
  type User, 
  type InsertUser, 
  type Notice, 
  type InsertNotice, 
  type FileUpload, 
  type InsertFileUpload,
  type Course,
  type InsertCourse,
  type Enrollment,
  type InsertEnrollment,
  type Assignment,
  type InsertAssignment,
  type Submission,
  type InsertSubmission,
  type Attendance,
  type InsertAttendance,
  type Schedule,
  type InsertSchedule,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql, lt } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// CRUD methods interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // Notice methods
  getNotices(limit?: number): Promise<Notice[]>;
  getNotice(id: number): Promise<Notice | undefined>;
  createNotice(notice: InsertNotice): Promise<Notice>;
  updateNotice(id: number, noticeData: Partial<InsertNotice>): Promise<Notice | undefined>;
  deleteNotice(id: number): Promise<boolean>;
  
  // File upload methods
  getFileUploads(): Promise<FileUpload[]>;
  getFileUpload(id: number): Promise<FileUpload | undefined>;
  createFileUpload(fileUpload: InsertFileUpload): Promise<FileUpload>;
  deleteFileUpload(id: number): Promise<boolean>;
  
  // Course methods
  getCourse(id: number): Promise<Course | undefined>;
  getStudentCourses(studentId: number): Promise<Course[]>;
  getTeacherCourses(teacherId: number): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, courseData: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;
  
  // Enrollment methods
  getEnrollment(id: number): Promise<Enrollment | undefined>;
  getEnrollmentByStudentAndCourse(studentId: number, courseId: number): Promise<Enrollment | undefined>;
  getStudentEnrollments(studentId: number): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: number, enrollmentData: Partial<InsertEnrollment>): Promise<Enrollment | undefined>;
  deleteEnrollment(id: number): Promise<boolean>;
  isStudentEnrolledInCourse(studentId: number, courseId: number): Promise<boolean>;
  
  // Assignment methods
  getAssignment(id: number): Promise<Assignment | undefined>;
  getCourseAssignments(courseId: number): Promise<Assignment[]>;
  getStudentAssignments(studentId: number): Promise<Assignment[]>;
  getUpcomingAssignments(studentId: number): Promise<Assignment[]>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: number, assignmentData: Partial<InsertAssignment>): Promise<Assignment | undefined>;
  deleteAssignment(id: number): Promise<boolean>;
  
  // Submission methods
  getSubmission(id: number): Promise<Submission | undefined>;
  getStudentSubmissions(studentId: number): Promise<Submission[]>;
  getAssignmentSubmissions(assignmentId: number): Promise<Submission[]>;
  getAllSubmissions(): Promise<Submission[]>;
  createSubmission(submission: Partial<InsertSubmission>): Promise<Submission>;
  updateSubmission(id: number, submissionData: Partial<InsertSubmission>): Promise<Submission | undefined>;
  deleteSubmission(id: number): Promise<boolean>;
  
  // Attendance methods
  getAttendance(id: number): Promise<Attendance | undefined>;
  getStudentAttendance(studentId: number): Promise<Attendance[]>;
  getCourseAttendance(courseId: number): Promise<Attendance[]>;
  getDateAttendance(date: Date): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<boolean>;
  
  // Schedule methods
  getSchedule(id: number): Promise<Schedule | undefined>;
  getCourseSchedules(courseId: number): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, scheduleData: Partial<InsertSchedule>): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.Store;
}

// PostgreSQL session store
const PostgresSessionStore = connectPg(session);

// DatabaseStorage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Notice methods
  async getNotices(limit?: number): Promise<Notice[]> {
    if (limit) {
      return await db.select().from(notices).orderBy(desc(notices.createdAt)).limit(limit);
    } else {
      return await db.select().from(notices).orderBy(desc(notices.createdAt));
    }
  }

  async getNotice(id: number): Promise<Notice | undefined> {
    const [notice] = await db.select().from(notices).where(eq(notices.id, id));
    return notice;
  }

  async createNotice(notice: InsertNotice): Promise<Notice> {
    const [createdNotice] = await db.insert(notices).values(notice).returning();
    return createdNotice;
  }

  async updateNotice(id: number, noticeData: Partial<InsertNotice>): Promise<Notice | undefined> {
    const [updatedNotice] = await db
      .update(notices)
      .set(noticeData)
      .where(eq(notices.id, id))
      .returning();
    return updatedNotice;
  }

  async deleteNotice(id: number): Promise<boolean> {
    const result = await db.delete(notices).where(eq(notices.id, id)).returning();
    return result.length > 0;
  }

  // File upload methods
  async getFileUploads(): Promise<FileUpload[]> {
    return await db.select().from(fileUploads).orderBy(desc(fileUploads.uploadedAt));
  }

  async getFileUpload(id: number): Promise<FileUpload | undefined> {
    const [fileUpload] = await db.select().from(fileUploads).where(eq(fileUploads.id, id));
    return fileUpload;
  }

  async createFileUpload(fileUpload: InsertFileUpload): Promise<FileUpload> {
    const [createdFileUpload] = await db.insert(fileUploads).values(fileUpload).returning();
    return createdFileUpload;
  }

  async deleteFileUpload(id: number): Promise<boolean> {
    const result = await db.delete(fileUploads).where(eq(fileUploads.id, id)).returning();
    return result.length > 0;
  }
  
  // Course methods
  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }
  
  async getStudentCourses(studentId: number): Promise<Course[]> {
    // Get courses through enrollments
    const studentEnrollments = await db
      .select({
        courseId: enrollments.courseId
      })
      .from(enrollments)
      .where(and(
        eq(enrollments.studentId, studentId),
        eq(enrollments.isActive, true)
      ));
    
    if (studentEnrollments.length === 0) {
      return [];
    }
    
    // Get the courses for these enrollments
    const courseIds = studentEnrollments.map(e => e.courseId);
    return await db
      .select()
      .from(courses)
      .where(sql`${courses.id} IN (${courseIds})`)
      .orderBy(courses.name);
  }
  
  async getTeacherCourses(teacherId: number): Promise<Course[]> {
    return await db
      .select()
      .from(courses)
      .where(eq(courses.teacherId, teacherId))
      .orderBy(courses.name);
  }
  
  async createCourse(course: InsertCourse): Promise<Course> {
    const [createdCourse] = await db.insert(courses).values(course).returning();
    return createdCourse;
  }
  
  async updateCourse(id: number, courseData: Partial<InsertCourse>): Promise<Course | undefined> {
    const [updatedCourse] = await db
      .update(courses)
      .set(courseData)
      .where(eq(courses.id, id))
      .returning();
    return updatedCourse;
  }
  
  async deleteCourse(id: number): Promise<boolean> {
    const result = await db.delete(courses).where(eq(courses.id, id)).returning();
    return result.length > 0;
  }
  
  // Enrollment methods
  async getEnrollment(id: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db.select().from(enrollments).where(eq(enrollments.id, id));
    return enrollment;
  }
  
  async getEnrollmentByStudentAndCourse(studentId: number, courseId: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(and(
        eq(enrollments.studentId, studentId),
        eq(enrollments.courseId, courseId)
      ));
    return enrollment;
  }
  
  async getStudentEnrollments(studentId: number): Promise<Enrollment[]> {
    return await db
      .select()
      .from(enrollments)
      .where(eq(enrollments.studentId, studentId))
      .orderBy(desc(enrollments.enrolledAt));
  }
  
  async createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment> {
    const [createdEnrollment] = await db.insert(enrollments).values(enrollment).returning();
    return createdEnrollment;
  }
  
  async updateEnrollment(id: number, enrollmentData: Partial<InsertEnrollment>): Promise<Enrollment | undefined> {
    const [updatedEnrollment] = await db
      .update(enrollments)
      .set(enrollmentData)
      .where(eq(enrollments.id, id))
      .returning();
    return updatedEnrollment;
  }
  
  async deleteEnrollment(id: number): Promise<boolean> {
    const result = await db.delete(enrollments).where(eq(enrollments.id, id)).returning();
    return result.length > 0;
  }
  
  async isStudentEnrolledInCourse(studentId: number, courseId: number): Promise<boolean> {
    const enrollment = await this.getEnrollmentByStudentAndCourse(studentId, courseId);
    return !!enrollment && enrollment.isActive;
  }
  
  // Assignment methods
  async getAssignment(id: number): Promise<Assignment | undefined> {
    const [assignment] = await db.select().from(assignments).where(eq(assignments.id, id));
    return assignment;
  }
  
  async getCourseAssignments(courseId: number): Promise<Assignment[]> {
    return await db
      .select()
      .from(assignments)
      .where(eq(assignments.courseId, courseId))
      .orderBy(assignments.dueDate);
  }
  
  async getStudentAssignments(studentId: number): Promise<Assignment[]> {
    // First get all courses the student is enrolled in
    const enrolledCourses = await this.getStudentCourses(studentId);
    
    if (enrolledCourses.length === 0) {
      return [];
    }
    
    // Get assignments for these courses
    const courseIds = enrolledCourses.map(c => c.id);
    return await db
      .select()
      .from(assignments)
      .where(sql`${assignments.courseId} IN (${courseIds})`)
      .orderBy(assignments.dueDate);
  }
  
  async getUpcomingAssignments(studentId: number): Promise<Assignment[]> {
    // First get all courses the student is enrolled in
    const enrolledCourses = await this.getStudentCourses(studentId);
    
    if (enrolledCourses.length === 0) {
      return [];
    }
    
    // Get assignments for these courses that are due in the future
    const courseIds = enrolledCourses.map(c => c.id);
    const now = new Date();
    
    return await db
      .select()
      .from(assignments)
      .where(and(
        sql`${assignments.courseId} IN (${courseIds})`,
        gte(assignments.dueDate, now)
      ))
      .orderBy(assignments.dueDate)
      .limit(10);
  }
  
  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const [createdAssignment] = await db.insert(assignments).values(assignment).returning();
    return createdAssignment;
  }
  
  async updateAssignment(id: number, assignmentData: Partial<InsertAssignment>): Promise<Assignment | undefined> {
    const [updatedAssignment] = await db
      .update(assignments)
      .set(assignmentData)
      .where(eq(assignments.id, id))
      .returning();
    return updatedAssignment;
  }
  
  async deleteAssignment(id: number): Promise<boolean> {
    const result = await db.delete(assignments).where(eq(assignments.id, id)).returning();
    return result.length > 0;
  }
  
  // Submission methods
  async getSubmission(id: number): Promise<Submission | undefined> {
    const [submission] = await db.select().from(submissions).where(eq(submissions.id, id));
    return submission;
  }
  
  async getStudentSubmissions(studentId: number): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .where(eq(submissions.studentId, studentId))
      .orderBy(desc(submissions.submittedAt));
  }
  
  async getAssignmentSubmissions(assignmentId: number): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .where(eq(submissions.assignmentId, assignmentId))
      .orderBy(desc(submissions.submittedAt));
  }
  
  async getAllSubmissions(): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .orderBy(desc(submissions.submittedAt));
  }
  
  async createSubmission(submission: Partial<InsertSubmission>): Promise<Submission> {
    const [createdSubmission] = await db.insert(submissions).values(submission as InsertSubmission).returning();
    return createdSubmission;
  }
  
  async updateSubmission(id: number, submissionData: Partial<InsertSubmission>): Promise<Submission | undefined> {
    const [updatedSubmission] = await db
      .update(submissions)
      .set(submissionData)
      .where(eq(submissions.id, id))
      .returning();
    return updatedSubmission;
  }
  
  async deleteSubmission(id: number): Promise<boolean> {
    const result = await db.delete(submissions).where(eq(submissions.id, id)).returning();
    return result.length > 0;
  }
  
  // Attendance methods
  async getAttendance(id: number): Promise<Attendance | undefined> {
    const [attendanceRecord] = await db.select().from(attendance).where(eq(attendance.id, id));
    return attendanceRecord;
  }
  
  async getStudentAttendance(studentId: number): Promise<Attendance[]> {
    return await db
      .select()
      .from(attendance)
      .where(eq(attendance.studentId, studentId))
      .orderBy(desc(attendance.date));
  }
  
  async getCourseAttendance(courseId: number): Promise<Attendance[]> {
    return await db
      .select()
      .from(attendance)
      .where(eq(attendance.courseId, courseId))
      .orderBy(desc(attendance.date));
  }
  
  async getDateAttendance(date: Date): Promise<Attendance[]> {
    // Use sql template for the date comparison
    const dateStr = date.toISOString().split('T')[0];
    
    return await db
      .select()
      .from(attendance)
      .where(sql`${attendance.date} = ${dateStr}`)
      .orderBy(attendance.courseId);
  }
  
  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [createdAttendance] = await db.insert(attendance).values(attendanceData).returning();
    return createdAttendance;
  }
  
  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }
  
  async deleteAttendance(id: number): Promise<boolean> {
    const result = await db.delete(attendance).where(eq(attendance.id, id)).returning();
    return result.length > 0;
  }
  
  // Schedule methods
  async getSchedule(id: number): Promise<Schedule | undefined> {
    const [schedule] = await db.select().from(schedules).where(eq(schedules.id, id));
    return schedule;
  }
  
  async getCourseSchedules(courseId: number): Promise<Schedule[]> {
    return await db
      .select()
      .from(schedules)
      .where(eq(schedules.courseId, courseId))
      .orderBy(schedules.dayOfWeek, schedules.startTime);
  }
  
  async createSchedule(schedule: InsertSchedule): Promise<Schedule> {
    const [createdSchedule] = await db.insert(schedules).values(schedule).returning();
    return createdSchedule;
  }
  
  async updateSchedule(id: number, scheduleData: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    const [updatedSchedule] = await db
      .update(schedules)
      .set(scheduleData)
      .where(eq(schedules.id, id))
      .returning();
    return updatedSchedule;
  }
  
  async deleteSchedule(id: number): Promise<boolean> {
    const result = await db.delete(schedules).where(eq(schedules.id, id)).returning();
    return result.length > 0;
  }
}

// Export the storage instance
export const storage = new DatabaseStorage();
