import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireAdmin, requireRole } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import { insertNoticeSchema, insertFileUploadSchema } from "@shared/schema";

// Configure multer for file uploads
const uploadsDir = path.join(process.cwd(), "uploads");

// Ensure uploads directory exists
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage_multer = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueFilename = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueFilename);
  },
});

const upload = multer({
  storage: storage_multer,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept images, PDFs, and office documents
    const allowedMimes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only images, PDFs, and office documents are allowed."));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // Static route for uploads
  app.use('/uploads', (req, res, next) => {
    // Allow access to public files without authentication
    // Authenticate access to protected files if needed
    next();
  }, express.static(uploadsDir));
  
  // API routes
  
  // Get notices (public)
  app.get("/api/notices", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const notices = await storage.getNotices(limit);
      res.json(notices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notices" });
    }
  });
  
  // Get single notice (public)
  app.get("/api/notices/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const notice = await storage.getNotice(id);
      
      if (!notice) {
        return res.status(404).json({ error: "Notice not found" });
      }
      
      res.json(notice);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notice" });
    }
  });
  
  // Create notice (admin/teacher only)
  app.post("/api/notices", requireRole("teacher"), async (req, res) => {
    try {
      // requireRole middleware ensures req.user exists
      if (!req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      // Validate request body
      const validatedData = insertNoticeSchema.parse({
        ...req.body,
        authorId: req.user.id
      });
      
      const notice = await storage.createNotice(validatedData);
      res.status(201).json(notice);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // Update notice (admin/teacher only)
  app.put("/api/notices/:id", requireRole("teacher"), async (req, res) => {
    try {
      // requireRole middleware ensures req.user exists
      if (!req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      const notice = await storage.getNotice(id);
      
      if (!notice) {
        return res.status(404).json({ error: "Notice not found" });
      }
      
      // Only allow admins or the original author to update
      if (req.user.role !== "admin" && notice.authorId !== req.user.id) {
        return res.status(403).json({ error: "You don't have permission to update this notice" });
      }
      
      const updatedNotice = await storage.updateNotice(id, req.body);
      res.json(updatedNotice);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // Delete notice (admin/teacher only)
  app.delete("/api/notices/:id", requireRole("teacher"), async (req, res) => {
    try {
      // requireRole middleware ensures req.user exists
      if (!req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      const notice = await storage.getNotice(id);
      
      if (!notice) {
        return res.status(404).json({ error: "Notice not found" });
      }
      
      // Only allow admins or the original author to delete
      if (req.user.role !== "admin" && notice.authorId !== req.user.id) {
        return res.status(403).json({ error: "You don't have permission to delete this notice" });
      }
      
      const result = await storage.deleteNotice(id);
      
      if (result) {
        res.status(204).send();
      } else {
        res.status(500).json({ error: "Failed to delete notice" });
      }
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // File uploads API
  
  // Get all file uploads (admin only)
  app.get("/api/uploads", requireAdmin, async (req, res) => {
    try {
      const files = await storage.getFileUploads();
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch file uploads" });
    }
  });
  
  // Upload a file (authenticated users only)
  app.post("/api/uploads", upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      const fileData = {
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        path: `/uploads/${req.file.filename}`,
        uploaderId: req.user.id
      };
      
      // Validate and save file data
      const validatedData = insertFileUploadSchema.parse(fileData);
      const fileUpload = await storage.createFileUpload(validatedData);
      
      res.status(201).json(fileUpload);
    } catch (error) {
      // Delete the file if there was an error saving to database
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // Delete file upload (admin or uploader only)
  app.delete("/api/uploads/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const id = parseInt(req.params.id);
      const fileUpload = await storage.getFileUpload(id);
      
      if (!fileUpload) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Only admin or original uploader can delete
      if (req.user.role !== "admin" && fileUpload.uploaderId !== req.user.id) {
        return res.status(403).json({ error: "You don't have permission to delete this file" });
      }
      
      // Delete file from filesystem
      const filePath = path.join(uploadsDir, fileUpload.filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      
      // Delete from database
      const result = await storage.deleteFileUpload(id);
      
      if (result) {
        res.status(204).send();
      } else {
        res.status(500).json({ error: "Failed to delete file" });
      }
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // Student Dashboard API Routes
  
  // Get student's courses
  app.get("/api/courses", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const courses = await storage.getStudentCourses(req.user.id);
      res.json(courses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch courses" });
    }
  });
  
  // Get a specific course by ID
  app.get("/api/courses/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ error: "Course not found" });
      }
      
      // Check if student is enrolled in this course
      const isEnrolled = await storage.isStudentEnrolledInCourse(req.user.id, courseId);
      const isTeacherOrAdmin = req.user.role === "teacher" || req.user.role === "admin";
      const isCourseTaught = req.user.role === "teacher" && course.teacherId === req.user.id;
      
      if (!isEnrolled && !isTeacherOrAdmin && !isCourseTaught) {
        return res.status(403).json({ error: "You don't have access to this course" });
      }
      
      res.json(course);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch course" });
    }
  });
  
  // Get assignments for a student
  app.get("/api/assignments", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const assignments = await storage.getStudentAssignments(req.user.id);
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assignments" });
    }
  });
  
  // Get upcoming assignments for a student
  app.get("/api/assignments/upcoming", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const assignments = await storage.getUpcomingAssignments(req.user.id);
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch upcoming assignments" });
    }
  });
  
  // Get a specific assignment by ID
  app.get("/api/assignments/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const assignmentId = parseInt(req.params.id);
      const assignment = await storage.getAssignment(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ error: "Assignment not found" });
      }
      
      // Check if student is enrolled in the course for this assignment
      if (req.user.role === "student") {
        const isEnrolled = await storage.isStudentEnrolledInCourse(req.user.id, assignment.courseId);
        if (!isEnrolled) {
          return res.status(403).json({ error: "You don't have access to this assignment" });
        }
      }
      
      res.json(assignment);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch assignment" });
    }
  });
  
  // Submit an assignment
  app.post("/api/submissions", upload.single("file"), async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      if (req.user.role !== "student") {
        return res.status(403).json({ error: "Only students can submit assignments" });
      }
      
      const assignmentId = parseInt(req.body.assignmentId);
      if (!assignmentId) {
        return res.status(400).json({ error: "Assignment ID is required" });
      }
      
      // Check if the assignment exists and student is enrolled in the course
      const assignment = await storage.getAssignment(assignmentId);
      if (!assignment) {
        return res.status(404).json({ error: "Assignment not found" });
      }
      
      const isEnrolled = await storage.isStudentEnrolledInCourse(req.user.id, assignment.courseId);
      if (!isEnrolled) {
        return res.status(403).json({ error: "You don't have access to this assignment" });
      }
      
      // Check if assignment is past due date
      const now = new Date();
      const dueDate = new Date(assignment.dueDate);
      const isLate = now > dueDate;
      
      let attachmentId = null;
      
      // If a file was uploaded, save it first
      if (req.file) {
        const fileData = {
          filename: req.file.filename,
          originalName: req.file.originalname,
          mimeType: req.file.mimetype,
          size: req.file.size,
          path: `/uploads/${req.file.filename}`,
          uploaderId: req.user.id
        };
        
        // Validate and save file data
        const validatedFileData = insertFileUploadSchema.parse(fileData);
        const fileUpload = await storage.createFileUpload(validatedFileData);
        attachmentId = fileUpload.id;
      }
      
      // Prepare submission data
      const submissionData = {
        assignmentId,
        studentId: req.user.id,
        content: req.body.content || null,
        attachmentId,
        isLate
      };
      
      // Save the submission
      const submission = await storage.createSubmission(submissionData);
      res.status(201).json(submission);
    } catch (error) {
      // Delete the file if there was an error saving to database
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error occurred" });
    }
  });
  
  // Get student's submissions
  app.get("/api/submissions", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      if (req.user.role === "student") {
        const submissions = await storage.getStudentSubmissions(req.user.id);
        res.json(submissions);
      } else if (req.user.role === "teacher" || req.user.role === "admin") {
        const submissions = await storage.getAllSubmissions();
        res.json(submissions);
      } else {
        res.status(403).json({ error: "Unauthorized" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch submissions" });
    }
  });
  
  // Get student's attendance records
  app.get("/api/attendance", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      if (req.user.role === "student") {
        const attendance = await storage.getStudentAttendance(req.user.id);
        res.json(attendance);
      } else {
        res.status(403).json({ error: "Unauthorized" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch attendance records" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
